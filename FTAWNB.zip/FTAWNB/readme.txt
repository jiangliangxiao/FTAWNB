The detailed processes of using the code（WEKA 3.7）：
1、Put FTAWNB.java into directory: weka.classifiers.bayes
2、Run WEKA, choose Experimenter/Explorer window, add the datasets, choose bayes.FTAWNB algorithm, then click "start". 